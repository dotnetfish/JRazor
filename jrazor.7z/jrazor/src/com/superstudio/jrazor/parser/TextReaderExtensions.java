package com.superstudio.jrazor.parser;

public final class TextReaderExtensions
{
	
}