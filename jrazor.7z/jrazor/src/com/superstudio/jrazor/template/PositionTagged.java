package com.superstudio.jrazor.template;

public class PositionTagged<T> {

	public T getValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getPosition() {
		// TODO Auto-generated method stub
		return 0;
	}

}
