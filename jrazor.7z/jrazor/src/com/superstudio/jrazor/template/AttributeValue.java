package com.superstudio.jrazor.template;

import com.superstudio.jrazor.template.PositionTagged;

public class AttributeValue {

	public PositionTagged<Object> getValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public PositionTagged<String> getPrefix() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean getLiteral() {
		// TODO Auto-generated method stub
		return false;
	}

}
