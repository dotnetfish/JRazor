package com.superstudio.jrazor.template;

public class Cache {

}
