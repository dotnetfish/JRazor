package com.superstudio.jrazor.template;

public class VirtualPathFactory implements IVirtualPathFactory {

	
	public boolean Exists(String virtualPath) {
		// TODO Auto-generated method stub
		return false;
	}

	//@Override
	public <T> T CreateInstance(String virtualPath) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
