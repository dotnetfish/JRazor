package com.superstudio.jrazor.template;

import com.superstudio.jrazor.templateEngine.TemplateFileInfo;

public interface ITemplateFile {
	 TemplateFileInfo getTemplateInfo();
}
