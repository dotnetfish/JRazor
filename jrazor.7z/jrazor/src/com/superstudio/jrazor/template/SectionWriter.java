package com.superstudio.jrazor.template;

@FunctionalInterface
public interface SectionWriter {
	 void execute();
}
