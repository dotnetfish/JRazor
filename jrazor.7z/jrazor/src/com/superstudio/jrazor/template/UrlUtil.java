package com.superstudio.jrazor.template;

/*

public class UrlUtil {

	public static String GenerateClientUrl(HttpContextBase context, String virtualPath, String path,
			Object[] pathParts) {
		// TODO Auto-generated method stub
		return null;
	}

}
*/
