package com.superstudio.jrazor.template;

import java.io.Writer;

import com.superstudio.web.HttpContextBase;

public class InstrumentationService {

	public boolean getIsAvailable() {
		// TODO Auto-generated method stub
		return false;
	}

	public void EndContext(HttpContextBase context, String virtualPath, Writer writer, int startPosition,
			int length, boolean isLiteral) {
		// TODO Auto-generated method stub
		
	}

	public void BeginContext(HttpContextBase context, String virtualPath, Writer writer, int startPosition,
			int length, boolean isLiteral) {
		// TODO Auto-generated method stub
		
	}

}
