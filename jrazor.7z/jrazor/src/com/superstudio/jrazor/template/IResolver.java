package com.superstudio.jrazor.template;


public interface IResolver<T>
{
	T getCurrent();
}