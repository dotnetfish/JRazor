package com.superstudio.jrazor.template;

import java.io.Writer;

public class TemplateContext {

	public void setWriter(Writer oldWriter) {
		// TODO Auto-generated method stub
		
	}

	public Writer getWriter() {
		// TODO Auto-generated method stub
		return null;
	}

	public TemplateHostContext getContext() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isMobile() {
		// TODO Auto-generated method stub
		return false;
	}

}
