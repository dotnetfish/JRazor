package com.superstudio.jrazor.template;

public class CommonResources {

	public static final String Argument_Cannot_Be_Null_Or_Empty = null;

	public static String getArgument_Cannot_Be_Null_Or_Empty() {
		// TODO Auto-generated method stub
		return null;
	}

	public static String getArgument_Must_Be_GreaterThanOrEqualTo() {
		// TODO Auto-generated method stub
		return null;
	}

}
