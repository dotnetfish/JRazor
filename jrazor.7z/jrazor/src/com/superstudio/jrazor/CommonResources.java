package com.superstudio.jrazor;

public class CommonResources {

	public static final String Argument_Cannot_Be_Null_Or_Empty = null;

}
