package com.superstudio.web.razor.utils;



public final class EnumeratorExtensions
{

	public static <T> Iterable<T> Flatten(Iterable<Iterable<T>> source)
	{

		//return source.SelectMany(e -> e);
		return null;
	}
}