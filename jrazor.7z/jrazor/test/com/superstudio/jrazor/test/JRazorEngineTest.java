package com.superstudio.jrazor.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class JRazorEngineTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
